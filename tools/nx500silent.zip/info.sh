#!/bin/sh
st cap capdtm setusr 117 0x00750001
killall -KILL dfmsd

