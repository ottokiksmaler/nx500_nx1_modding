#!/bin/bash
/mnt/mmc/scripts/resup VGA 2K
