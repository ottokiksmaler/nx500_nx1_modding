#!/bin/bash
/opt/home/scripts/popup_timeout  " [ Otto : BT-mod, keyscan, poker, gui,... ] " 3
/opt/home/scripts/popup_timeout  " [ KS : can be found at www.fb.com/KinoSeed/ ] " 3
exit
