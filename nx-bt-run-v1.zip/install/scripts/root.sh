shell script /mnt/mmc/scripts/inst-bt.sh
