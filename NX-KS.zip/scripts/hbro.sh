#!/bin/bash
/opt/home/scripts/popup_timeout  " [ Coming Soon... ] " 3