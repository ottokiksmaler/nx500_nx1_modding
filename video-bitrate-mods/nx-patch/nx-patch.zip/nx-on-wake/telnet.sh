#!/bin/bash
/opt/usr/nx-on-wake/telnetd &
/opt/usr/nx-on-wake/popup_timeout "Telnet IP: `cat /var/run/memory/dnet/ip | cut -c 2-`" 10 &
