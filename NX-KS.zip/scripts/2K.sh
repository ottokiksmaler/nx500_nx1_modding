#!/bin/bash
/opt/home/scripts/resup VGA 2K
