#!/bin/bash
reboot