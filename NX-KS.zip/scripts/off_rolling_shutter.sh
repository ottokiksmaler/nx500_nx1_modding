#!/bin/bash
/usr/bin/st cap capdtm setusr ADJUSTSHUTTERTYPE 0x750000
exit
