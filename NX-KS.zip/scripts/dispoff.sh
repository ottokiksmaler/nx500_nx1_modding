#!/bin/bash
renice -n 0 -p $$
yell() { echo "$0: $*" >&2; }
die() { yell "$*"; exit 111; }
ticking() {
	end=$((SECONDS+$1))
	while [ $SECONDS -lt $end ]; do
		if [[ "$(cat /sdcard/presets/asleep)" >""  ]]; then rm /sdcard/presets/asleep; 
 			st app disp lcd
			die; fi
	    sleep 0.5
	done
}
[ -d "/mnt/mmc/presets" ] || mkdir /mnt/mmc/presets

st app disp evf

cat /dev/event0 > /sdcard/presets/asleep &
cat /dev/event1 >> /sdcard/presets/asleep &

ticking 99999

exit

