#!/bin/bash

# run the patcher
. /tmp/initial_patches.sh

# rebuild menus to reflect current state
/bin/awk 'BEGIN { FS="[: ]" }; /nx500:[DUFHV].+/ { print "button|" $2 " ( now: " substr($3, 3) " )|@/opt/usr/nx-on-wake/chg_res_" tolower($2) ".nx500\nbutton| |" } END { print "button| |\nbutton|back|@/opt/usr/nx-on-wake/main.NX500"; }' /tmp/initial_patches.sh >/tmp/resolutions.nx500
/bin/awk 'BEGIN { FS="[: ]" }; /nx1:[DUFHV].+/   { print "button|" $2 " ( now: " substr($3, 3) " )|@/opt/usr/nx-on-wake/chg_res_" tolower($2) ".nx1\nbutton| |"   } END { print "button| |\nbutton|back|@/opt/usr/nx-on-wake/main.NX1"  ; }' /tmp/initial_patches.sh >/tmp/resolutions.nx1
/bin/awk 'BEGIN { FS="[: ]" }; /nx500:p.+/   { print "button|" $2 " ( now: " $3 " )|/opt/usr/nx-on-wake/set_rate.sh " $3 " nx500 " $2  } END { print "button| |\nbutton| |\nbutton|back|@/opt/usr/nx-on-wake/bitrates.nx500"; }' /tmp/initial_patches.sh >/tmp/bitrates-p.nx500
/bin/awk 'BEGIN { FS="[: ]" }; /nx500:h.+/   { print "button|" $2 " ( now: " $3 " )|/opt/usr/nx-on-wake/set_rate.sh " $3 " nx500 " $2  } END { print "button| |\nbutton|back|@/opt/usr/nx-on-wake/bitrates.nx500"; }' /tmp/initial_patches.sh >/tmp/bitrates-h.nx500
/bin/awk 'BEGIN { FS="[: ]" }; /nx500:n.+/   { print "button|" $2 " ( now: " $3 " )|/opt/usr/nx-on-wake/set_rate.sh " $3 " nx500 " $2  } END { print "button| |\nbutton|back|@/opt/usr/nx-on-wake/bitrates.nx500"; }' /tmp/initial_patches.sh >/tmp/bitrates-n.nx500
/bin/awk 'BEGIN { FS="[: ]" }; /nx1:p.+/     { print "button|" $2 " ( now: " $3 " )|/opt/usr/nx-on-wake/set_rate.sh " $3 " nx1   " $2  } END { print "button| |\nbutton|back|@/opt/usr/nx-on-wake/bitrates.nx1"; }' /tmp/initial_patches.sh >/tmp/bitrates-p.nx1
/bin/awk 'BEGIN { FS="[: ]" }; /nx1:h.+/     { print "button|" $2 " ( now: " $3 " )|/opt/usr/nx-on-wake/set_rate.sh " $3 " nx1   " $2  } END { print "button| |\nbutton| |\nbutton|back|@/opt/usr/nx-on-wake/bitrates.nx1"; }' /tmp/initial_patches.sh >/tmp/bitrates-h.nx1
/bin/awk 'BEGIN { FS="[: ]" }; /nx1:n.+/     { print "button|" $2 " ( now: " $3 " )|/opt/usr/nx-on-wake/set_rate.sh " $3 " nx1   " $2  } END { print "button| |\nbutton| |\nbutton|back|@/opt/usr/nx-on-wake/bitrates.nx1"; }' /tmp/initial_patches.sh >/tmp/bitrates-n.nx1
