#!/bin/bash
renice -n 0 -p $$ > /dev/null

if [ $(/bin/grep ^NX500$ /etc/version.info) = "NX500" -a $(/bin/grep ^1.11$ /etc/version.info) = "1.11" ]; then
#NX500
mq=$(prefman get 0 0x0000a368  b);  mq=( $mq )
mq=${mq[5]}
cb=$( /mnt/mmc/scripts/gbr )
[[  "$cb" == "" ]] && /mnt/mmc/scripts/popup_timeout  " [  Profile Not Adjustable  ] " 2 && exit
br=$(/mnt/mmc/scripts/popup_entry "Current Bitrate: $cb Mbps" "Apply Change" Cancel)

mz=$(prefman get 0 0x0000a360  b);  mz=( $mz )
mz=${mz[5]}
case "$mz" in
0)  [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro1 $br 
[[  "$mq" == "1" ]] &&  /mnt/mmc/scripts/pokemon hq1 $br 
    ;;
1)   [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro1 $br 
[[  "$mq" == "1" ]] &&   /mnt/mmc/scripts/pokemon hq1 $br 
    ;;
2)   [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro2 $br 
[[  "$mq" == "1" ]] &&   /mnt/mmc/scripts/pokemon hq2 $br 
	;;
3)   [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro3 $br 
[[  "$mq" == "1" ]] &&   /mnt/mmc/scripts/pokemon hq3 $br 
   ;;
4)   [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro3 $br 
[[  "$mq" == "1" ]] &&    /mnt/mmc/scripts/pokemon hq3 $br
   ;;
6)  [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon hq4 $br
[[  "$mq" == "1" ]] && /mnt/mmc/scripts/pokemon hq4 $br
   ;;
9)  [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon hq5 $br
[[  "$mq" == "1" ]] && /mnt/mmc/scripts/pokemon hq5 $br
   ;;
10) [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon hq6 $br
[[  "$mq" == "1" ]] && /mnt/mmc/scripts/pokemon hq6 $br
   ;;
*) ;;
esac

elif [ $(/bin/grep   ^NX1$   /etc/version.info) = "NX1" -a $(/bin/grep ^1.40$ /etc/version.info) = "1.40" ]; then
#NX1
mq=$(prefman get 0 0x00000338  b);  mq=( $mq ) 
mq=${mq[5]}
cb=$( /mnt/mmc/scripts/gbr )
[[  "$cb" == "" ]] && /mnt/mmc/scripts/popup_timeout  " [  Profile Not Adjustable  ] " 2 && exit
br=$(/mnt/mmc/scripts/popup_entry "Current Bitrate: $cb Mbps" "Apply Change" Cancel)

mz=$(prefman get 0 0x00000330  b);  mz=( $mz )
mz=${mz[5]}
case "$mz" in
0)  [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro1 $br 
[[  "$mq" == "1" ]] &&  /mnt/mmc/scripts/pokemon hq1 $br 
    ;;
1)   [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro1 $br 
[[  "$mq" == "1" ]] &&   /mnt/mmc/scripts/pokemon hq1 $br 
    ;;
2)   [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro1 $br 
[[  "$mq" == "1" ]] &&   /mnt/mmc/scripts/pokemon hq1 $br 
	;;
3)   [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro1 $br 
[[  "$mq" == "1" ]] &&   /mnt/mmc/scripts/pokemon hq1 $br 
   ;;
4)   [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro1 $br 
[[  "$mq" == "1" ]] &&    /mnt/mmc/scripts/pokemon hq2 $br
   ;;
5)   [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro1 $br 
[[  "$mq" == "1" ]] &&    /mnt/mmc/scripts/pokemon hq2 $br
   ;;
6)   [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro2 $br 
[[  "$mq" == "1" ]] &&    /mnt/mmc/scripts/pokemon hq3 $br
   ;;
7)   [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro2 $br 
[[  "$mq" == "1" ]] &&    /mnt/mmc/scripts/pokemon hq3 $br
   ;;
8)   [[  "$mq" == "2" ]] && /mnt/mmc/scripts/pokemon pro2 $br 
[[  "$mq" == "1" ]] &&    /mnt/mmc/scripts/pokemon hq3 $br
   ;;
*) ;;
esac
fi
killall mod_gui
exit
