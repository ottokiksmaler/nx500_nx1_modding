#!/bin/bash
renice -n -10 -p $$
[[ $(echo $(st cap capdtm getusr MONITOROUT) | grep LCD) > ""  ]] && /opt/home/scripts/popup_timeout  " [ Mod v2.04 by Otto / KS ] " 3 &
systemctl set-environment fps=4
