#!/bin/bash
br=$(/mnt/mmc/scripts/popup_entry "Change Bitrate for $1" "Apply Change" Cancel)

[[  "$br" == "" ]] && /mnt/mmc/scripts/popup_timeout  " [  NOT SET  ] " 2 && exit

case "$1" in
4K-ProQ)  /mnt/mmc/scripts/pokemon pro1 $br; systemctl set-environment Pro4K=$br
    ;;
HD-ProQ) /mnt/mmc/scripts/pokemon pro2 $br; /mnt/mmc/scripts/pokemon pro3 $br; systemctl set-environment ProHD=$br
    ;;
4K-HQ)  /mnt/mmc/scripts/pokemon hq1 $br; systemctl set-environment Hq4K=$br
    ;;
HD-HQ) /mnt/mmc/scripts/pokemon hq2 $br; /mnt/mmc/scripts/pokemon hq3 $br; /mnt/mmc/scripts/pokemon hq4 $br; systemctl set-environment HqHD=$br
   ;;
VGA-HQ) /mnt/mmc/scripts/pokemon hq5 $br; /mnt/mmc/scripts/pokemon hq6 $br; systemctl set-environment HqVGA=$br
   ;;
*)
;;
esac
 sync;sync;sync
/sdcard/scripts/br_up.sh

