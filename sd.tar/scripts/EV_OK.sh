st app lens pzoom tele
st app set izoom 2.0

