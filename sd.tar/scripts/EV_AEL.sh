if [ -a /tmp/mode_raw ]; then
  rm -f /tmp/mode_raw
  st app nx capture quality sfine
else 
  touch /tmp/mode_raw
  st app nx capture quality raw
fi
