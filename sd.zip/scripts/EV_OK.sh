/mnt/mmc/scripts/focus_stack
