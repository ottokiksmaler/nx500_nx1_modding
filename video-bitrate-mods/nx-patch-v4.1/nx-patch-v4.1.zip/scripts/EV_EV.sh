#!/bin/bash
# force lcd on
st app disp lcd
sleep 0.5
# launch the UI
/opt/usr/scripts/mod_gui /opt/usr/scripts/main &
