#!/bin/bash
/opt/storage/sdcard/scripts/nx-ba.sh
