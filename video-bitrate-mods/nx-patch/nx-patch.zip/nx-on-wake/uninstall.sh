#!/bin/bash
res=$(/opt/usr/nx-on-wake/popup_entry "Enter 197 to confirm" Confirm Cancel 999 number)
if [ $res -eq 197 ]; then
    # re-enable 30 min recording limit
  if [ `/opt/storage/sdcard/install/nx-model` = nx1 ]; then
    /usr/bin/prefman set 0 0x306d l 0
  else
    /usr/bin/prefman set 0 0xc2d9 l 0
  fi
    # the popup is killed if the file is erased
  cp /opt/usr/nx-on-wake/popup_timeout /tmp
  /tmp/popup_timeout "Please wait... uninstalling." 4 &
  rm -rf /opt/usr/nx-on-wake/*
  sync;sync;sync
  sleep 5
  /tmp/popup_timeout "Done, thank you." 3
fi
