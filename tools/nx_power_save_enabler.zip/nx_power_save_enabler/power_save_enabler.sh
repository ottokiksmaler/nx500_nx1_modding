#!/bin/sh
killall -KILL dfmsd && sleep 3
dfmsd -t &
sleep 3
dfmstool -s "osd string 2 Otto Kiksmaler NX1/NX500 Power Save Disabler"

# find address with recording limit flag
ADDR=`prefman info 0|grep APPPREF_B_DISABLE_POWER_SAVE|cut -f 2 -d' '`

LIMIT="30 min LIMIT"
test `prefman get 0 $ADDR l  | grep value| cut -f 4 -d' '` -eq 1 && LIMIT="NO LIMIT"
dfmstool -s "osd string 4 POWER SAVE OLD: $LIMIT"

# disable recording limit
prefman set 0 $ADDR l 0

LIMIT="30 min LIMIT"
test `prefman get 0 $ADDR l  | grep value| cut -f 4 -d' '` -eq 1 && LIMIT="NO LIMIT"
dfmstool -s "osd string 5 POWER SAVE NEW: $LIMIT"

mv /mnt/mmc/info.tg /mnt/mmc/info_DISABLED.tg
prefman save && sync && sync && sync && dfmstool -s "osd string 6 SETTINGS SAVED"
dfmstool -s "osd string 7 Restarting in 10 seconds"
sleep 10
killall -KILL dfmsd
st key click pwoff
