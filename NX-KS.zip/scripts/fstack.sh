nice -n -50 /opt/home/scripts/focus_stack &
