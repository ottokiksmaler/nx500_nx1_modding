#!/bin/bash
/opt/home/scripts/resup UHD 1080P
rm -f /opt/home/scripts/auto/res_UHD2K.sh
exit
