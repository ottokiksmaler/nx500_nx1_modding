#!/bin/bash
res=$(/opt/usr/scripts/popup_entry "Enter 194 to confirm" Confirm Cancel 999 number)
if [ $res -eq 194 ]; then
  cp /opt/usr/scripts/popup_timeout /tmp
  /tmp/popup_timeout "Please wait... uninstalling." 4 &
  if [ -x /usr/sbin/bluetoothd.orig ]; then
    mount -o remount,rw /
    rm /usr/sbin/bluetoothd
    mv /usr/sbin/bluetoothd.orig /usr/sbin/bluetoothd
    mount -o remount,ro /
  fi
  sync;sync;sync
  sleep 5
    # enable 30 min recording limit
  if [ $(/mnt/mmc/install/nx-model) != "nx1" ]; then
    /usr/bin/prefman set 0 0x306d l 0
  else
    /usr/bin/prefman set 0 0xc2d9 l 0
  fi
  /tmp/popup_timeout "Rebooting." 3
  rm -Rf /opt/usr/scripts; reboot
fi
