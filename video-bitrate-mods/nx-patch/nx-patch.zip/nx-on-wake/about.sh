#!/bin/bash
/opt/usr/nx-on-wake/popup_ok "Copyright (C) 2016  Vasile Dumitrescu (ppnx.vasile@dfgh.net); keyscan, mod_gui, popup_* copyright (C) 2016 Otto Kiksmaler https://github.com/ottokiksmaler"
