#!/bin/bash
#
#                             nx-ba.sh    v2.0
#
#                  Samsung NX1 & NX500 Bitrate Adjustment
#
#   Copyright (C) 2016  Vasile Dumitrescu, (nxhack.vasile@dfgh.net)
#
#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 3 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software Foundation,
#   Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301  USA
#
#        WARNING WARNING WARNING WARNING WARNING WARNING WARNING
#
#            this will work ONLY on:
#                NX1 with firmware v1.40 and
#                NX500 with firmware v1.11
#
#        WARNING WARNING WARNING WARNING WARNING WARNING WARNING
#
#   Usage: see README.txt file enclosed in the package
#
#   DO NOT proceed until you have read (twice) and understood README.txt
#
#   If you can manage it, please turn off your brain and mechanically
#   apply the steps outlined in the README.txt file :-)
#
echo set \$isNX1=$(/bin/grep   ^NX1$   /etc/version.info &>/dev/null && \
  /bin/grep ^1.40$ /etc/version.info &>/dev/null; echo $((1-$?))) >/tmp/isNX1.gdb
echo set \$isNX500=$(/bin/grep ^NX500$ /etc/version.info &>/dev/null && \
  /bin/grep ^1.11$ /etc/version.info &>/dev/null; echo $((1-$?))) >/tmp/isNX500.gdb
/mnt/mmc/scripts/gdb --nx --quiet --batch --command=/mnt/mmc/scripts/nx-ba.gdb
