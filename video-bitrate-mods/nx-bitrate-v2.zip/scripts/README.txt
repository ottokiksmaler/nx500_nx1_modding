            Samsung NX1 and NX500 Video Bitrate Adjustment

                               v2.0

                              How To

This script allows you to replace SOME of the NX-series built-in bitrates.

I might consider replacing other bitrates at a later time but this is
quite time consuming as it involves hand-coding multiple ARM instructions.

Usage:

  0. Make sure your NX camera is on firmware v1.40 (NX1) or v1.11 (NX500)
  1. Make sure that Otto's SD card bluetooth execute method is ENABLED.
       => look for Running_scripts_without_factory_mode_BT.md on
          https://github.com/ottokiksmaler/nx500_nx1_modding/
     
     The package containing the file you are reading now also includes
     a zipfile that implements Otto's mod in a relatively easy to use manner.
        Zip file name: nx-bt-run-v1.zip, unzip it on your computer and read 
        its README.txt.
     
     I repeat: the mod contained in nx-bt-run-v1.zip MUST be installed before
     you proceed with this video bitrate mod.

  2. If you are a Windows user, make sure you have either Notepad++
       or another text editor capable of editing Linux-formatted files.
       Notepad++ can be found at https://notepad-plus-plus.org/.
     If you are a Linux user you can use vi or nano or your other 
       preferred equivalent tool.
  3. Open in the text editor (see point 2 above) the file nx-ba.gdb
     from the scripts folder of the SD card.
  4. Open the scripts/nx-bitrate-map.png to identify replaceable bitrates for
     each camera. Note the names they are given, e.g. nx1_pro1, etc.
  5. Make up your mind which bitrate(s) you want to change and
     decide which replacement bitrate you want for them.
  6. Locate the "bitrate definitions" section in the nx-ba.gdb file.
     It starts with this:
     
     ############ bitrate definitions #######################################
   
  7. The replacement bitrates range between 35 and 320 Mbps and they are named
     in a uniform way to make it easy for you to remember them.
     Familiarise yourself with them :-)
  8. Locate the bitrate replacement area in the file. It starts with this:
  
    ##################### bitrate replacement area #########################
  
  9. This section has two parts - one for NX1 and one for NX500.
     It has individual lines that replace the various rates, for example:
       - to replace the NX500 70 Mbps rate, you need to find the line
       
           nx500_pro1 $bitrate_140
           
         As you can see, the rate is labelled nx500_pro1 (self-explanatory,
         I hope, by reference to the nx-bitrate-map.png file).
         
         It is currently being replaced with 140 Mbps.
         
         Change it to whatever value you want, or comment it by putting a #
         at the beginning of the line.
         For example, to change it to 120 Mbps you need to replace the 140 in
         $bitrate_140 with 120, and you will end up with a line like this:
         
           nx500_pro1 $bitrate_120

 10. If you have both cameras, you can change both sections of the file, and 
     use it in both cameras - the script will detect the camera it runs in and
     only apply the appropriate changes.
     Make sure you do NOT otherwise touch the content of this file.
 11. Close and save the file.
 12. Pull the NX1 battery for a few seconds, and reinsert it.
 13. Insert the SD card with the mod into your camera - NB the script
     won't work otherwise. :-)
 14. Power on the camera - this is also a mandatory step !!!! :-)
 15. If bluetooth is not turned on, turn it on and wait until it is actually
     turned on. You can turn it off afterwards, the mod stays active until you
     turn off the camera, regardless of bluetooth state.
     
     The important point to understand is that the mod does not depend on the
     STATE of bluetooth, it is activated (and stays active thereafter) upon
     the bluetooth activation EVENT.
     
     Also, it is important to understand that the mod is inactive until the
     first bluetooth activation after each camera power up. If bluetooth is
     automatically activated (because it was on when the camera was turned off)
     there is no need to turn it off and on again, the mod is active.
     
 16. Read point 15 AGAIN, twice. You will save yourself angst and dpreview
     users will not have the occasion to ask you (kindly or not) to RTFM when
     you go there for help.

NB. The steps up to and including 13 are one-time (or until you decide you want
    another bitrate), and as long as you no longer touch the files you just put
    on the SD card and you keep the SD card inside the camera, it will keep
    using the adjusted bitrates.
    
    Also, in case it is still unclear: the same modded SD card can be used in
    both NX1 and NX500 (if you are lucky to have both) without change as it
    will dynamically apply only the appropriate changes to each camera.
    
    I did this to make sure you do not mistakenly use the wrong version of the
    mod in your cameras (e.g. you do not use NX1 version in NX500).

Congratulations, your new bitrates are activated.

  A final word:

If you find this script useful (I certainly hope so since I spent a great deal
of personal time on it), please consider a donation to give me additional
incentives to find more ways to improve these cameras :-)... that
16-50 S lens looks mighty attractive ;-)...

You can donate through paypal to ppnx.vasile@dfgh.net. Thank you.
