#!/bin/bash
/tmp/popup_timeout "Please wait... uninstalling." 4 &
/usr/bin/killall -q keyscan mod_gui popup_ok popup_entry popup_timeout focus_stack focus_buttons telnetd
/usr/bin/killall --signal SIGINT shutter_to_rec
rm -rf /opt/usr/nx-on-wake/*
sync;sync;sync
sleep 5
/tmp/popup_timeout "Done, thank you." 3 &
