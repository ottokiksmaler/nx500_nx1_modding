#!/bin/bash
/mnt/mmc/scripts/resup VGA VGA
