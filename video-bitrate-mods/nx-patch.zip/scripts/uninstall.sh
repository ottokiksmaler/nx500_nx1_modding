#!/bin/bash
# ========= force LCD on (crash on EVF) =========
st app disp lcd
sleep 1

cp /opt/usr/scripts/popup_timeout /tmp
/tmp/popup_timeout "Please wait... uninstalling." 4 &
if [ -x /usr/sbin/bluetoothd.orig ]; then
  mount -o remount,rw /
  rm /usr/sbin/bluetoothd
  mv /usr/sbin/bluetoothd.orig /usr/sbin/bluetoothd
  mount -o remount,ro /
fi
sync;sync;sync
sleep 5
/tmp/popup_timeout "Rebooting." 3
rm -Rf /opt/usr/scripts; reboot
