#!/bin/bash
killall -SIGINT shutter_to_rec
