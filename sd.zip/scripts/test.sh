#echo "---------scr--------" > /mnt/mmc/test
#date >> /mnt/mmc/test
#echo "--------------------" >> /mnt/mmc/test
#sync
#sync
#sync
/mnt/mmc/scripts/keyscan /dev/event0 /dev/event1 /mnt/mmc/scripts/ &
sync
sync
sync
sleep 2
killall dfmsd
