#!/bin/sh
killall -KILL dfmsd && sleep 3
dfmsd -t &
sleep 3
dfmstool -s "osd string 2 Otto's Lapse Installer"

dfmstool -s "osd string 4 Installing to EV+OK"

test -d "/opt/usr/nx-on-wake" && DEST="/opt/usr/nx-on-wake/"
test -d "/opt/usr/scripts" && DEST="/opt/usr/scripts/"
cp /mnt/mmc/install/* $DEST && dfmstool -s "osd string 5 Install OK"
mv /mnt/mmc/info.tg /mnt/mmc/info_DISABLED.tg
sync;sync;sync
dfmstool -s "osd string 6 Rebooting in 10 seconds"
sleep 10
reboot

