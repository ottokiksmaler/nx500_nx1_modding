#!/bin/bash
swapoff /opt/usr/home/swapmod
rm /opt/usr/home/swapmod
/opt/home/scripts/popup_timeout  " [ Swap Removed ] " 2