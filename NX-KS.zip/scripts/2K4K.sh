#!/bin/bash
/opt/home/scripts/resup DC 2K
exit
