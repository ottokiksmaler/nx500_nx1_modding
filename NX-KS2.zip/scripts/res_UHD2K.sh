#!/bin/bash
/opt/home/scripts/resup UHD 2K
rm -f /opt/home/scripts/auto/res_UHDHD.sh
exit
