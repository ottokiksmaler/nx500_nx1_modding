#!/bin/bash
killall -q keyscan
killall -q mod_gui
sync;sync;sync
exit
