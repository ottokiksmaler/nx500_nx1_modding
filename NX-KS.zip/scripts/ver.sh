#!/bin/bash
/mnt/mmc/scripts/popup_timeout  " [ Otto : BT-mod, keyscan, poker, gui,... ] " 3
/mnt/mmc/scripts/popup_timeout  " [ Vasile : bitrate values, 2.5K patch ] " 3
/mnt/mmc/scripts/popup_timeout  " [ KS :... had a lot of coffees :) ] " 3
