#!/bin/bash
/mnt/mmc/scripts/popup_timeout  " [ Coming Soon... ] " 3