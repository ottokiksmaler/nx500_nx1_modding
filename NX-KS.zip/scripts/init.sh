#!/bin/bash

#Check if it's already running
#for i in "${tii[@]}"; do if [[ $i == "mod=ed"* ]]; then /mnt/mmc/scripts/popup_timeout  " [  Already Run  ] " 2; exit; fi; done

renice -n -20 -p $$
# Choose Bitrates ( no added spaces! make sure it looks like Pro4K=90 )
#       Available bitrates in Mbps: 35,40,45,50,55,60,65,70,75,80,85,90,95,
#       100,110,120,130,140,150,160,170,180,190,
#       200,210,220,230,240,250,260,270,280,290,300,310,320
#############################################
Pro4K=180   #nx500-pro1         / nx1-pro1
ProHD=160   #nx500-pro2&pro3    / nx1-pro2
Hq4K=100    #nx500-hq1          / nx1-hq1&hq2
HqHD=90     #nx500-hq2&hq3&hq4  / nx1-hq3
HqVGA=100   #nx500-hq5&hq6
#############################################

/mnt/mmc/scripts/pokemon pro1 $Pro4K
/mnt/mmc/scripts/pokemon pro2 $ProHD
/mnt/mmc/scripts/pokemon pro3 $ProHD
/mnt/mmc/scripts/pokemon hq1 $Hq4K
/mnt/mmc/scripts/pokemon hq2 $HqHD
/mnt/mmc/scripts/pokemon hq3 $HqHD
/mnt/mmc/scripts/pokemon hq4 $HqHD
/mnt/mmc/scripts/pokemon hq5 $HqVGA
/mnt/mmc/scripts/pokemon hq6 $HqVGA



systemctl set-environment Pro4K=$Pro4K
systemctl set-environment ProHD=$ProHD
systemctl set-environment Hq4K=$Hq4K
systemctl set-environment HqHD=$HqHD
systemctl set-environment HqVGA=$HqVGA

[[ $(echo $(st cap capdtm getusr MONITOROUT) | grep LCD) > ""  ]] && /mnt/mmc/scripts/popup_timeout  " [ Mod v.1.42 ] " 2 &

renice -n 20 -p $$

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
export DISPLAY=":0"
export ECORE_IMF_MODULE="isf"
export ECORE_INPUT_FIX="1"
export ECORE_INPUT_TIMEOUT_FIX="0"
export EINA_LOG_DLOG_ENABLE="0" #1
export EINA_LOG_LEVEL="1"
export EINA_LOG_LEVELS="ecore_x:4,evas_main:1"
export EINA_LOG_SYSLOG_ENABLE="0"
export ELM_MODULES="ctxpopup_copypasteUI>entry/api:datetime_input_button>datetime/api:object_dump>win/api:access_output_tts>access/api"
export ELM_PROFILE="mobile"
export EVAS_FONT_DPI="72"
export EVAS_GL_NO_BLACKLIST="1"
export GTK_IM_MODULE="scim"
export GTK_IM_MODULE_FILE="/opt/etc/gtk-2.0/gtk.immodules"
export HIB="a"
export HISTSIZE="1000"
export HOME="/root"
export HUSHLOGIN="FALSE"
export LD_LIBRARY_PATH=":/usr/lib:/usr/lib/driver"
export LOGNAME="root"
export MULTISENSE_SND_PLAYER="tizen_snd_player"
export OLDPWD
export PATH="/usr/share/scripts:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/opt/usr/devel/usr/sbin:/opt/usr/devel/usr/bin:/opt/usr/devel/sbin:/opt/usr/devel/bin"
export SCIM_MODULE_PATH="/opt/apps/scim/lib/scim-1.0"
export SHELL="/bin/sh"
export SHLVL="2"
export TERM="vt102"
export USER="root"
export XDG_CACHE_HOME="/tmp/.cache"
export XMODIFIERS="@im=SCIM"

$DIR/keyscan /dev/event0 /dev/event1 $DIR &

#Set Recording-Batch-Length in seconds
systemctl set-environment rbl=840

#Indicate it's now running
#systemctl set-environment mod=ed

af_info=($(st cap iq af pos))
st cap iq af mv 10 $(($(head -n 1 /mnt/mmc/presets/hib) - ${af_info[2]} )) 10
sync
sync
sync
exit

