#!/bin/bash
killall --signal SIGINT shutter_to_rec
