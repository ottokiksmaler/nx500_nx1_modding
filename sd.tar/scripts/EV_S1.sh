st cap capt light on body; st cap capt light off body;sleep 0.5
st cap capt light on body; st cap capt light off body;sleep 0.5
st cap capt light on body; st cap capt light off body;sleep 0.5
st cap capt light on body; st cap capt light off body;sleep 0.5
st cap capt light on body; st cap capt light off body;sleep 0.5
st cap capt light on body; st cap capt light off body;sleep 0.1
st cap capt light on body; st cap capt light off body;sleep 0.1
st cap capt light on body; st cap capt light off body;sleep 0.1
st cap capt light on body; sleep 1; st cap capt light off body;
st key push s1; st key push s2; st key release s2; st key release s1
