#!/bin/bash
if [ x`pgrep telnetd` != x ]; then
    # this is being run as auto script; telnet was active before; need to disable it
  killall telnetd
  rm /opt/usr/nx-on-wake/auto/telnet.sh
else
    # let us start telnetd
  /opt/usr/nx-on-wake/telnetd &
  IP=`cat /var/run/memory/dnet/ip | cut -c 2-`
  if [ x$IP != x ]; then
    /opt/usr/nx-on-wake/popup_timeout "IP address: $IP" 6 &
  else
    /opt/usr/nx-on-wake/popup_timeout "WiFi is off => no IP" 3 &
  fi
fi
