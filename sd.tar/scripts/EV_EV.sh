#killall dfmsd
if [ -a /tmp/mode_single ]; then
  rm -f /tmp/mode_single
  st app nx capture af-mode caf
  st app drive conti_h
else 
  touch /tmp/mode_single
  st app nx capture af-mode single
  st app drive single
fi
