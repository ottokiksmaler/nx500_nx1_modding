#!/bin/bash
/opt/home/scripts/resup DC 2K
rm -f /opt/home/scripts/auto/res_DCHD.sh
exit
