shell script /mnt/mmc/scripts/del-bt.sh
