#!/bin/bash

# run the patcher
. /tmp/initial_patches.sh

# rebuild menus to reflect current state
/bin/awk 'BEGIN { FS="[: ]" }; /nx500:[DUFHV].+/ { print "button|" $2 " ( now: " substr($3, 3) " )|@/opt/usr/nx-on-wake/chg_res_" tolower($2) ".NX500\nbutton|-|" }' /tmp/initial_patches.sh >/tmp/resolutions.NX500
/bin/awk 'BEGIN { FS="[: ]" }; /nx1:[DUFHV].+/   { print "button|" $2 " ( now: " substr($3, 3) " )|@/opt/usr/nx-on-wake/chg_res_" tolower($2) ".NX1\nbutton|-|"   }' /tmp/initial_patches.sh >/tmp/resolutions.NX1
/bin/awk 'BEGIN { FS="[: ]" }; /nx500:p.+/   { print "button|" $2 " ( now: " $3 " )|/opt/usr/nx-on-wake/set_rate.sh " $3 " nx500 " $2  }' /tmp/initial_patches.sh >/tmp/bitrates-p.NX500
/bin/awk 'BEGIN { FS="[: ]" }; /nx500:h.+/   { print "button|" $2 " ( now: " $3 " )|/opt/usr/nx-on-wake/set_rate.sh " $3 " nx500 " $2  }' /tmp/initial_patches.sh >/tmp/bitrates-h.NX500
/bin/awk 'BEGIN { FS="[: ]" }; /nx500:n.+/   { print "button|" $2 " ( now: " $3 " )|/opt/usr/nx-on-wake/set_rate.sh " $3 " nx500 " $2  }' /tmp/initial_patches.sh >/tmp/bitrates-n.NX500
/bin/awk 'BEGIN { FS="[: ]" }; /nx1:p.+/     { print "button|" $2 " ( now: " $3 " )|/opt/usr/nx-on-wake/set_rate.sh " $3 " nx1   " $2  }' /tmp/initial_patches.sh >/tmp/bitrates-p.NX1
/bin/awk 'BEGIN { FS="[: ]" }; /nx1:h.+/     { print "button|" $2 " ( now: " $3 " )|/opt/usr/nx-on-wake/set_rate.sh " $3 " nx1   " $2  }' /tmp/initial_patches.sh >/tmp/bitrates-h.NX1
/bin/awk 'BEGIN { FS="[: ]" }; /nx1:n.+/     { print "button|" $2 " ( now: " $3 " )|/opt/usr/nx-on-wake/set_rate.sh " $3 " nx1   " $2  }' /tmp/initial_patches.sh >/tmp/bitrates-n.NX1
