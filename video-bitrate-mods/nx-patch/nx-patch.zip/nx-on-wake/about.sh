#!/bin/bash
/opt/usr/nx-on-wake/popup_ok "<div align="left">Copyright 2016  Vasile Dumitrescu<br>               (ppnx.vasile@dfgh.net)<br><br>keyscan, mod_gui, popup_* focus_* shutter_to_rec Copyright Otto Kiksmaler https://github.com/ottokiksmaler</div>"
