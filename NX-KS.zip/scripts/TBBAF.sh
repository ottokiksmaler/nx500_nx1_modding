#!/bin/bash
/opt/home/scripts/popup_timeout  " [ TBBAF - ON  ] " 1 &
/opt/home/scripts/poker2 /sys/devices/platform/d5keys-polled/keymask 0x0:307830303030303830300a
