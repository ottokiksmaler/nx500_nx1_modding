#!/bin/bash
/opt/home/scripts/resup VGA VGA
