#!/bin/bash
killall telnetd
