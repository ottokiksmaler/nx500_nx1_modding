#!/bin/bash
/opt/home/scripts/resup DC DC
exit
