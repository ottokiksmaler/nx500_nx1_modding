killall telnetd
sleep 1
/mnt/mmc/scripts/telnetd &
IP=`ip addr ls|grep inet|grep mlan0|cut -d/ -f 1`
dfmsd -t &
sleep 2
dfmstool -s "osd string 7 IP ADDRESS $IP"
sleep 30
killall dfmsd

