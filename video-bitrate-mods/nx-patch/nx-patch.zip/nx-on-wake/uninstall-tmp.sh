#!/bin/bash
/tmp/popup_timeout "Please wait... uninstalling." 4 &
rm -rf /opt/usr/nx-on-wake/*
sync;sync;sync
sleep 5
/tmp/popup_timeout "Done, thank you." 3 &
