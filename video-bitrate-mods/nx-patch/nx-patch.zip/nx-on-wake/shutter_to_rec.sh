#!/bin/bash
killall --signal SIGINT shutter_to_rec
/opt/usr/nx-on-wake/shutter_to_rec &
