#!/bin/bash
/opt/home/scripts/resup DC 1080P
rm -f /opt/home/scripts/auto/res_DC2K.sh
exit
